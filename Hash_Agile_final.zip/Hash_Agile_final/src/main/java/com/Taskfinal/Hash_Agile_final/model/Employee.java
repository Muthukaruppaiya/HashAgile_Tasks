package com.Taskfinal.Hash_Agile_final.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import java.time.LocalDate;

@Document(indexName = "hash_muthukaruppaiya2368")
public class Employee {

    @Id
    private String id;
    private String fullName;
    private String jobTitle;
    private String department;
    private String businessUnit;
    private String gender;
    private String ethnicity;
    private int age;
    private LocalDate hireDate;
    private double annualSalary;
    private double bonusPercentage;
    private String country;
    private String city;
    private LocalDate exitDate;
    private LocalDate parsedDateOfBirth; // Ensure this is relevant to your business logic

    // Constructors
    public Employee(String id, String fullName, String jobTitle, String department, String businessUnit, 
                    String gender, String ethnicity, int age, LocalDate hireDate, double annualSalary, 
                    double bonusPercentage, String country, String city, LocalDate exitDate) {
        this.id = id;
        this.fullName = fullName;
        this.jobTitle = jobTitle;
        this.department = department;
        this.businessUnit = businessUnit;
        this.gender = gender;
        this.ethnicity = ethnicity;
        this.age = age;
        this.hireDate = hireDate;
        this.annualSalary = annualSalary;
        this.bonusPercentage = bonusPercentage;
        this.country = country;
        this.city = city;
        this.exitDate = exitDate;
    }

    public Employee() {
        // Default constructor
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getBusinessUnit() {
        return businessUnit;
    }

    public void setBusinessUnit(String businessUnit) {
        this.businessUnit = businessUnit;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEthnicity() {
        return ethnicity;
    }

    public void setEthnicity(String ethnicity) {
        this.ethnicity = ethnicity;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public LocalDate getHireDate() {
        return hireDate;
    }

    public void setHireDate(LocalDate hireDate) {
        this.hireDate = hireDate;
    }

    public double getAnnualSalary() {
        return annualSalary;
    }

    public void setAnnualSalary(double annualSalary) {
        this.annualSalary = annualSalary;
    }

    public double getBonusPercentage() {
        return bonusPercentage;
    }

    public void setBonusPercentage(double bonusPercentage) {
        this.bonusPercentage = bonusPercentage;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public LocalDate getExitDate() {
        return exitDate;
    }

    public void setExitDate(LocalDate exitDate) {
        this.exitDate = exitDate;
    }

    public LocalDate getParsedDateOfBirth() {
        return parsedDateOfBirth;
    }

    public void setParsedDateOfBirth(LocalDate parsedDateOfBirth) {
        this.parsedDateOfBirth = parsedDateOfBirth;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id='" + id + '\'' +
                ", fullName='" + fullName + '\'' +
                ", jobTitle='" + jobTitle + '\'' +
                ", department='" + department + '\'' +
                ", businessUnit='" + businessUnit + '\'' +
                ", gender='" + gender + '\'' +
                ", ethnicity='" + ethnicity + '\'' +
                ", age=" + age +
                ", hireDate=" + hireDate +
                ", annualSalary=" + annualSalary +
                ", bonusPercentage=" + bonusPercentage +
                ", country='" + country + '\'' +
                ", city='" + city + '\'' +
                ", exitDate=" + exitDate +
                ", parsedDateOfBirth=" + parsedDateOfBirth +
                '}';
    }
}
