package com.Taskfinal.Hash_Agile_final.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Taskfinal.Hash_Agile_final.model.Employee;
import com.Taskfinal.Hash_Agile_final.db.repo.EmployeeRepository;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public List<Employee> getAllEmployees() {
        return (List<Employee>) employeeRepository.findAll(); 
    }

    public Optional<Employee> getEmployeeById(String id) {
        return employeeRepository.findById(id); 
    }

    public Employee addEmployee(Employee employee) {
        return employeeRepository.save(employee); 
    }
}
