package com.Taskfinal.Hash_Agile_final.db.repo;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import com.Taskfinal.Hash_Agile_final.model.Employee;

import java.util.List;

public interface EmployeeRepository extends ElasticsearchRepository<Employee, String> {
    List<Employee> findByFullName(String fullName); // Method to find employees by full name
    List<Employee> findByDepartment(String department); // Method to find employees by department
}
