package com.Taskfinal.Hash_Agile_final;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HashAgileFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
